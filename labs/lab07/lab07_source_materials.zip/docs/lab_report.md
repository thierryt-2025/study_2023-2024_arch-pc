# Lab 07 Report
**Course:** Computer Architecture  
**Student:** Thierry Tuyishime  
**Date:** $(date +%Y-%m-%d)

## Objective


## Tasks Completed


## Results


## Screenshots


## Conclusions

