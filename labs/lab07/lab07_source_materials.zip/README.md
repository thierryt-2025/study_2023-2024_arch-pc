# Lab 07 Archive - Computer Architecture

## Directory Structure
- `src/` - Original source files
- `docs/` - Documentation (PDF, Markdown)
- `screenshots/` - Screenshots and images
- `code/` - Source code files
- `resources/` - Additional resources and references

## Contents
- Lab instructions and documentation
- Source code implementations
- Screenshots of results/outputs
- Additional reference materials
